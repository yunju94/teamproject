package maker;


import com.itextpdf.io.exceptions.IOException;

import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import java.sql.*;
import java.io.File;
import java.util.*;


import com.oreilly.servlet.multipart.*;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;



public class pdftester {
	
	
	static Basic base = new Basic();

	private static Connection conn;
	  
	private static PreparedStatement pstmt;

	    
	    
	 public static void main(String[] args) throws java.io.IOException {
		
	        String dest = "table.pdf";
	        new pdftester().createPDF(dest);
	    }
	    public void createPDF(String dest) throws java.io.IOException {
	    	 
          	 
            	List<Map<String, String>> books = createDummyData();//books

     	        PdfWriter writer = new PdfWriter(dest);
     	        PdfDocument pdf = new PdfDocument(writer);
     	        Document document = new Document(pdf, PageSize.A4);

     	        PdfFont headerFont = null;
     	        PdfFont bodyFont = null;

     	        headerFont = PdfFontFactory.createFont("HYGoThic-Medium", "UniKS-UCS2-H");
     	        bodyFont = PdfFontFactory.createFont("HYGoThic-Medium", "UniKS-UCS2-H");

     	        float[] columnWidths = {1, 2, 2, 2, 2, 2};
     	        Table table = new Table(UnitValue.createPointArray(columnWidths));
     	        table.setWidth(UnitValue.createPercentValue(100));

     	        Cell hCell1 = new Cell().add(new Paragraph("일련번호")).setFont(headerFont);
     	        Cell hCell2 = new Cell().add(new Paragraph("이름")).setFont(headerFont);
     	        Cell hCell3 = new Cell().add(new Paragraph("전화번호")).setFont(headerFont);
     	        Cell hCell4 = new Cell().add(new Paragraph("출판사")).setFont(headerFont);
     	        Cell hCell5 = new Cell().add(new Paragraph("출판일")).setFont(headerFont);
     	        Cell hCell6 = new Cell().add(new Paragraph("이미지")).setFont(headerFont);
     	        table.addHeaderCell(hCell1);
     	        table.addHeaderCell(hCell2);
     	        table.addHeaderCell(hCell3);
     	        table.addHeaderCell(hCell4);
     	        table.addHeaderCell(hCell5);
     	        table.addHeaderCell(hCell6);

     	        int rowNum =1;

     	        for (Map<String, String> book:books){
     	            String serialNo = book.get("serialNo");
     	            String name = book.get("name");
     	            String m_id = book.get("m_id");
     	            String birth = book.get("birth");
     	            String tel = book.get("tel");
     	            String age = book.get("age");
    	            String address = book.get("address");
    	            String grade = book.get("grade");
     	            String manager = book.get("manager");
     	            		
     	            		

     	            Cell rowNumCell = new Cell().add(new Paragraph(String.valueOf(rowNum))).setFont(bodyFont);
     	            table.addCell(rowNumCell);

     	            Cell serialNoCell = new Cell().add(new Paragraph(serialNo)).setFont(bodyFont);
     	            table.addCell(serialNoCell);

     	            Cell nameCell = new Cell().add(new Paragraph(name)).setFont(bodyFont);
     	            table.addCell(nameCell);

     	            Cell m_idCell = new Cell().add(new Paragraph(m_id)).setFont(bodyFont);
     	            table.addCell(m_idCell);

     	            Cell birthCell = new Cell().add(new Paragraph(birth)).setFont(bodyFont);
     	            table.addCell(birthCell);
     	            
     	            Cell telCell = new Cell().add(new Paragraph(tel)).setFont(bodyFont);
    	            table.addCell(telCell);
    	            
    	            Cell ageCell = new Cell().add(new Paragraph(age)).setFont(bodyFont);
     	            table.addCell(ageCell);
     	            
     	            
     	            Cell addressCell = new Cell().add(new Paragraph(address)).setFont(bodyFont);
    	            table.addCell(addressCell);
    	            
    	            Cell gradeCell = new Cell().add(new Paragraph(grade)).setFont(bodyFont);
     	            table.addCell(gradeCell);
     	            
     	           Cell managerCell = new Cell().add(new Paragraph(manager)).setFont(bodyFont);
    	            table.addCell(managerCell);

     	       
     	            rowNum++;
     	        }

     	        document.add(table);
     	        document.close();

     	    }
	  
     	    private  static List<Map<String, String>> createDummyData(){
     	        List<Map<String, String>> books = new ArrayList<>();
     	       
     	        	Map<String, String> book = new HashMap<>();
     	           
     	           
     	            book.put("serialNo", base.getSerialNo());
     	            
     	            book.put("name", base.getName());
     	            book.put("m_id", base.getM_id());
     	            book.put("birth", base.getBirth());
     	            book.put("tel", base.getTel());
     	            book.put("age", base.getAge());
     	            book.put("address", base.getAddress());
     	            book.put("grade",base.getGrade() );
     	            book.put("manager", base.getManager() );
     	            
     	           
     	            books.add(book);
     	      

    
     	        return books;



     	    }
		
         


}

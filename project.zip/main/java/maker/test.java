package maker;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
public class test {


	public class DatabaseToPDF {
	    public static void main(String[] args) {
	        try {
	            // 데이터베이스 연결
	            Class.forName("com.mysql.jdbc.Driver");
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "1234");
	            
	            // SQL 쿼리 작성
	            String query = "SELECT * FROM basicmembers";
	            Statement stmt = con.createStatement();
	            ResultSet rs = stmt.executeQuery(query);
	            
	            // PDF 생성
	            Document document = new Document();
	            PdfWriter.getInstance(document, new FileOutputStream("output.pdf"));
	            document.open();
	            
	            while (rs.next()) {
	                String data = rs.getString("serialNo");
	                document.add(new Paragraph(data));
	            }
	            
	            document.close();
	            con.close();
	            System.out.println("PDF 생성이 완료되었습니다.");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}

}
